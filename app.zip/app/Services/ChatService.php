<?php

namespace App\Services;

use App\Models\ChatRoom;
use App\Models\Chat;

class ChatService
{
    public function createRoom($user, $validated)
    {
        $room = ChatRoom::where('buyer_id', $user->id)
            ->where('seller_id', $validated['seller_id'])
            ->where('product_id', $validated['product_id'] ?? null)
            ->first();

        if (!$room) {

            $room = ChatRoom::create([
                'buyer_id' => $user->id,
                'seller_id' => $validated['seller_id'],
                'product_id' => $validated['product_id'] ?? null
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Chat room berhasil dibuat',
            'data' => $room
        ]);
    }

    public function sendMessage($user, $roomId, $validated)
    {
        $room = ChatRoom::find($roomId);

        if (!$room) {

            return response()->json([
                'status' => false,
                'message' => 'Chat room tidak ditemukan'
            ], 404);
        }

        if (
            $room->buyer_id != $user->id &&
            $room->seller_id != $user->id
        ) {

            return response()->json([
                'status' => false,
                'message' => 'Akses ditolak'
            ], 403);
        }

        $chat = Chat::create([
            'chat_room_id' => $room->id,
            'sender_id' => $user->id,
            'message' => $validated['message']
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Pesan berhasil dikirim',
            'data' => $chat
        ]);
    }
}