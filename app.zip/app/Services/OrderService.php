<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\CartItem;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderHistory;

use App\Models\Voucher;

use App\Http\Controllers\Api\Notification\NotificationController;

use Illuminate\Support\Str;

class OrderService
{
    public function checkout($user, $validated)
    {
        $cart = Cart::where('user_id', $user->id)
            ->with([
                'items.product',
                'items.variant'
            ])
            ->first();

        if (!$cart || $cart->items->count() == 0) {

            return response()->json([
                'status' => false,
                'message' => 'Cart kosong'
            ], 400);
        }

        $totalPrice = 0;

        foreach ($cart->items as $item) {

            $price = $item->variant
                ? $item->variant->price
                : $item->product->price;

            $subtotal = $price * $item->quantity;

            $totalPrice += $subtotal;
        }

        $discount = 0;

        if (!empty($validated['voucher_code'])) {

            $voucher = Voucher::where('code', $validated['voucher_code'])
                ->where('is_active', true)
                ->first();

            if ($voucher) {

                if (
                    $voucher->expired_at &&
                    now()->gt($voucher->expired_at)
                ) {

                    return response()->json([
                        'status' => false,
                        'message' => 'Voucher expired'
                    ], 400);
                }

                if ($voucher->quota <= $voucher->used) {

                    return response()->json([
                        'status' => false,
                        'message' => 'Voucher habis'
                    ], 400);
                }

                if ($totalPrice < $voucher->minimum_transaction) {

                    return response()->json([
                        'status' => false,
                        'message' => 'Minimum transaksi belum tercapai'
                    ], 400);
                }

                if ($voucher->discount_type == 'percentage') {

                    $discount =
                        ($totalPrice * $voucher->discount_value) / 100;

                } else {

                    $discount = $voucher->discount_value;
                }

                $voucher->increment('used');
            }
        }

        $finalTotal = $totalPrice - $discount;

        $order = Order::create([
            'user_id' => $user->id,
            'invoice_number' => 'INV-' . strtoupper(Str::random(10)),
            'total_price' => $finalTotal,
            'status' => 'pending'
        ]);

        OrderHistory::create([
            'order_id' => $order->id,
            'status' => 'pending',
            'description' => 'Order berhasil dibuat'
        ]);

        NotificationController::createNotification(
            $user->id,
            'Order Berhasil Dibuat',
            'Pesanan berhasil dibuat dengan invoice ' .
            $order->invoice_number
        );

        foreach ($cart->items as $item) {

            $price = $item->variant
                ? $item->variant->price
                : $item->product->price;

            $subtotal = $price * $item->quantity;

            OrderItem::create([
                'order_id' => $order->id,
                'product_id' => $item->product_id,
                'variant_id' => $item->variant_id,
                'quantity' => $item->quantity,
                'price' => $price,
                'subtotal' => $subtotal
            ]);
        }

        CartItem::where('cart_id', $cart->id)
            ->delete();

        return response()->json([
            'status' => true,
            'message' => 'Checkout berhasil',
            'data' => [
                'order' => $order,
                'discount' => $discount,
                'final_total' => $finalTotal
            ]
        ]);
    }
}