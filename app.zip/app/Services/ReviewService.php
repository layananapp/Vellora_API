<?php

namespace App\Services;

use App\Models\Review;

class ReviewService
{
    public function createReview($user, $validated)
    {
        $reviewExists = Review::where('user_id', $user->id)
            ->where('product_id', $validated['product_id'])
            ->where('order_id', $validated['order_id'] ?? null)
            ->first();

        if ($reviewExists) {

            return response()->json([
                'status' => false,
                'message' => 'Review sudah pernah dibuat'
            ], 400);
        }

        $review = Review::create([
            'user_id' => $user->id,
            'product_id' => $validated['product_id'],
            'order_id' => $validated['order_id'] ?? null,
            'rating' => $validated['rating'],
            'review' => $validated['review'] ?? null
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Review berhasil dibuat',
            'data' => $review
        ]);
    }
}