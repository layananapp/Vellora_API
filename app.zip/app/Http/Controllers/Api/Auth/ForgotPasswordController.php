<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ForgotPasswordController extends Controller
{
    public function forgotPassword(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email']
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user) {

            return response()->json([
                'status' => false,
                'message' => 'Email tidak ditemukan'
            ], 404);
        }

        $resetCode = rand(1000, 9999);

        $user->reset_code = $resetCode;
        $user->save();

        return response()->json([
            'status' => true,
            'message' => 'Kode reset berhasil dibuat',
            'reset_code' => $resetCode
        ]);
    }

        public function verifyResetCode(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email'],
            'reset_code' => ['required']
        ]);

        $user = User::where('email', $request->email)
            ->where('reset_code', $request->reset_code)
            ->first();

        if (!$user) {

            return response()->json([
                'status' => false,
                'message' => 'Kode reset salah'
            ], 400);
        }

        return response()->json([
            'status' => true,
            'message' => 'Kode reset valid'
        ]);
    }

        public function resetPassword(Request $request)
    {
        $request->validate([
            'email' => ['required', 'email'],
            'reset_code' => ['required'],
            'new_password' => ['required', 'min:8']
        ]);

        $user = User::where('email', $request->email)
            ->where('reset_code', $request->reset_code)
            ->first();

        if (!$user) {

            return response()->json([
                'status' => false,
                'message' => 'Reset password gagal'
            ], 400);
        }

        $user->password = Hash::make($request->new_password);
        $user->reset_code = null;
        $user->save();

        return response()->json([
            'status' => true,
            'message' => 'Password berhasil direset'
        ]);
    }
}