<?php

namespace App\Http\Controllers\Api\Wishlist;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Wishlist;
use App\Models\Product;

class WishlistController extends Controller
{
    public function addToWishlist(Request $request)
    {
        $user = $request->get('user');

        $validated = $request->validate([
            'product_id' => ['required', 'exists:products,id']
        ]);

        $wishlistExists = Wishlist::where('user_id', $user->id)
            ->where('product_id', $validated['product_id'])
            ->first();

        if ($wishlistExists) {

            return response()->json([
                'status' => false,
                'message' => 'Product sudah ada di wishlist'
            ], 400);
        }

        $wishlist = Wishlist::create([
            'user_id' => $user->id,
            'product_id' => $validated['product_id']
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Product berhasil ditambahkan ke wishlist',
            'data' => $wishlist
        ]);
    }

    public function getWishlist(Request $request)
    {
        $user = $request->get('user');

        $wishlists = Wishlist::where('user_id', $user->id)
            ->with([
                'product',
                'product.images',
                'product.store'
            ])
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $wishlists
        ]);
    }

    public function removeWishlist(Request $request, $id)
    {
        $user = $request->get('user');

        $wishlist = Wishlist::where('user_id', $user->id)
            ->find($id);

        if (!$wishlist) {

            return response()->json([
                'status' => false,
                'message' => 'Wishlist tidak ditemukan'
            ], 404);
        }

        $wishlist->delete();

        return response()->json([
            'status' => true,
            'message' => 'Wishlist berhasil dihapus'
        ]);
    }
}
