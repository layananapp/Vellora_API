<?php

namespace App\Http\Controllers\Api\Review;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Services\ReviewService;

use App\Models\Review;

class ReviewController extends Controller
{
    protected $reviewService;

    public function __construct(ReviewService $reviewService)
    {
        $this->reviewService = $reviewService;
    }

    public function createReview(Request $request)
    {
        $user = $request->get('user');

        $validated = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'order_id' => ['nullable', 'exists:orders,id'],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
            'review' => ['nullable']
        ]);

        return $this->reviewService
            ->createReview($user, $validated);
    }

    public function getProductReviews($productId)
    {
        $reviews = Review::where('product_id', $productId)
            ->with('user')
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $reviews
        ]);
    }
}