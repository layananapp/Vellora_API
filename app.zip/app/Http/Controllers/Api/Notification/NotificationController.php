<?php

namespace App\Http\Controllers\Api\Notification;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Notification;

class NotificationController extends Controller
{
    public static function createNotification(
        $userId,
        $title,
        $message
    )
    {
        return Notification::create([
            'user_id' => $userId,
            'title' => $title,
            'message' => $message
        ]);
    }

    public function getNotifications(Request $request)
    {
        $user = $request->get('user');

        $notifications = Notification::where('user_id', $user->id)
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $notifications
        ]);
    }

    public function markAsRead(Request $request, $id)
    {
        $user = $request->get('user');

        $notification = Notification::where('user_id', $user->id)
            ->find($id);

        if (!$notification) {

            return response()->json([
                'status' => false,
                'message' => 'Notification tidak ditemukan'
            ], 404);
        }

        $notification->update([
            'is_read' => true
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Notification berhasil dibaca',
            'data' => $notification
        ]);
    }
}
