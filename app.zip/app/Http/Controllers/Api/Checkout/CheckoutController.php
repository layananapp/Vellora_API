<?php

namespace App\Http\Controllers\Api\Checkout;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Services\OrderService;

class CheckoutController extends Controller
{
    protected $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->orderService = $orderService;
    }

    public function checkout(Request $request)
    {
        $user = $request->get('user');

        $validated = $request->validate([
            'voucher_code' => ['nullable']
        ]);

        return $this->orderService
            ->checkout($user, $validated);
    }
}