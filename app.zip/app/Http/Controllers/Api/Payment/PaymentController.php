<?php

namespace App\Http\Controllers\Api\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Services\PaymentService;

class PaymentController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    public function createPayment(Request $request, $orderId)
    {
        $user = $request->get('user');

        $validated = $request->validate([
            'payment_method' => ['required']
        ]);

        return $this->paymentService
            ->createPayment($user, $orderId, $validated);
    }

    public function paymentSuccess($paymentId)
    {
        return $this->paymentService
            ->paymentSuccess($paymentId);
    }
}