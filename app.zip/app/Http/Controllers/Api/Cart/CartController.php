<?php

namespace App\Http\Controllers\Api\Cart;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Services\CartService;

use App\Models\Cart;
use App\Models\CartItem;

class CartController extends Controller
{
    protected $cartService;

    public function __construct(CartService $cartService)
    {
        $this->cartService = $cartService;
    }

    public function addToCart(Request $request)
    {
        $user = $request->get('user');

        $validated = $request->validate([
            'product_id' => ['required', 'exists:products,id'],
            'variant_id' => ['nullable', 'exists:products_variants,id'],
            'quantity' => ['required', 'integer', 'min:1']
        ]);

        return $this->cartService
            ->addToCart($user, $validated);
    }

    public function updateCart(Request $request, $id)
    {
        $user = $request->get('user');

        $cart = Cart::where('user_id', $user->id)
            ->first();

        if (!$cart) {

            return response()->json([
                'status' => false,
                'message' => 'Cart tidak ditemukan'
            ], 404);
        }

        $cartItem = CartItem::where('cart_id', $cart->id)
            ->find($id);

        if (!$cartItem) {

            return response()->json([
                'status' => false,
                'message' => 'Cart item tidak ditemukan'
            ], 404);
        }

        $validated = $request->validate([
            'quantity' => ['required', 'integer', 'min:1']
        ]);

        $cartItem->update([
            'quantity' => $validated['quantity']
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Quantity cart berhasil diupdate',
            'data' => $cartItem
        ]);
    }

    public function removeCart(Request $request, $id)
    {
        $user = $request->get('user');

        $cart = Cart::where('user_id', $user->id)
            ->first();

        if (!$cart) {

            return response()->json([
                'status' => false,
                'message' => 'Cart tidak ditemukan'
            ], 404);
        }

        $cartItem = CartItem::where('cart_id', $cart->id)
            ->find($id);

        if (!$cartItem) {

            return response()->json([
                'status' => false,
                'message' => 'Cart item tidak ditemukan'
            ], 404);
        }

        $cartItem->delete();

        return response()->json([
            'status' => true,
            'message' => 'Cart item berhasil dihapus'
        ]);
    }

    public function clearCart(Request $request)
    {
        $user = $request->get('user');

        $cart = Cart::where('user_id', $user->id)
            ->first();

        if (!$cart) {

            return response()->json([
                'status' => false,
                'message' => 'Cart tidak ditemukan'
            ], 404);
        }

        CartItem::where('cart_id', $cart->id)
            ->delete();

        return response()->json([
            'status' => true,
            'message' => 'Cart berhasil dikosongkan'
        ]);
    }
}