<?php

namespace App\Http\Controllers\Api\Order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderHistory;   

use App\Http\Controllers\Api\Notification\NotificationController;   
use Illuminate\Support\Str;

class OrderController extends Controller
{

    public function getMyOrders(Request $request)
    {
        $user = $request->get('user');

        $orders = Order::where('user_id', $user->id)
            ->with([
                'items.product',
                'items.variant'
            ])
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $orders
        ]);
    }
    public function getOrderDetail(Request $request, $id)
    {
        $user = $request->get('user');

        $order = Order::where('user_id', $user->id)
            ->with([
                'items.product',
                'items.product.images',
                'items.variant'
            ])
            ->find($id);

        if (!$order) {

            return response()->json([
                'status' => false,
                'message' => 'Order tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $order
        ]);
    }
    public function getSellerOrders(Request $request)
    {
        $user = $request->get('user');

        $store = $user->store;

        if (!$store) {

            return response()->json([
                'status' => false,
                'message' => 'Store tidak ditemukan'
            ], 404);
        }

        $orders = Order::whereHas('items.product', function ($query) use ($store) {

            $query->where('store_id', $store->id);

        })->with([
            'user',
            'items.product',
            'items.variant'
        ])->latest()->get();

        return response()->json([
            'status' => true,
            'data' => $orders
        ]);
    }

    public function updateOrderStatus(Request $request, $id)
    {
        $user = $request->get('user');

        $store = $user->store;

        if (!$store) {

            return response()->json([
                'status' => false,
                'message' => 'Store tidak ditemukan'
            ], 404);
        }

        $order = Order::whereHas('items.product', function ($query) use ($store) {

            $query->where('store_id', $store->id);

        })->find($id);

        if (!$order) {

            return response()->json([
                'status' => false,
                'message' => 'Order tidak ditemukan'
            ], 404);
        }

        $validated = $request->validate([
            'status' => [
                'required',
                'in:processed,shipped,completed'
            ]
        ]);

        $order->update([
            'status' => $validated['status']
        ]);

        OrderHistory::create([
            'order_id' => $order->id,
            'status' => $validated['status'],
            'description' => 'Status order diubah menjadi ' . $validated['status']
        ]);

        NotificationController::createNotification(
            $order->user_id,
            'Status Order Diperbarui',
            'Status order sekarang: ' . $validated['status']
        );

        return response()->json([
            'status' => true,
            'message' => 'Status order berhasil diupdate',
            'data' => $order
        ]);
    }

    public function getOrderHistories(Request $request, $id)
    {
        $user = $request->get('user');

        $order = Order::where('user_id', $user->id)
            ->find($id);

        if (!$order) {

            return response()->json([
                'status' => false,
                'message' => 'Order tidak ditemukan'
            ], 404);
        }

        $histories = OrderHistory::where('order_id', $order->id)
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $histories
        ]);
    }

    public function cancelOrder(Request $request, $id)
    {
        $user = $request->get('user');

        $order = Order::where('user_id', $user->id)
            ->find($id);

        if (!$order) {

            return response()->json([
                'status' => false,
                'message' => 'Order tidak ditemukan'
            ], 404);
        }

        if ($order->status != 'pending') {

            return response()->json([
                'status' => false,
                'message' => 'Order tidak bisa dibatalkan'
            ], 400);
        }

        $order->update([
            'status' => 'cancelled'
        ]);

        OrderHistory::create([
            'order_id' => $order->id,
            'status' => 'cancelled',
            'description' => 'Order dibatalkan oleh user'
        ]);

        NotificationController::createNotification(
            $order->user_id,
            'Order Dibatalkan',
            'Order berhasil dibatalkan'
        );

        return response()->json([
            'status' => true,
            'message' => 'Order berhasil dibatalkan',
            'data' => $order
        ]);
    }
}