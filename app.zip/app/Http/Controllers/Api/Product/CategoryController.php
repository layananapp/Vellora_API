<?php

namespace App\Http\Controllers\Api\Product;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    public function createCategory(Request $request)
    {
        $validated = $request->validate([
            'category_name' => ['required']
        ]);

        $category = Category::create([
            'category_name' => $validated['category_name']
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Category berhasil dibuat',
            'data' => $category
        ]);
    }
}
