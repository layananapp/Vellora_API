<?php

namespace App\Http\Controllers\Api\Store;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Store;
use App\Models\Product;

class StoreController extends Controller
{

    public function createStore(Request $request)
    {
        $user = $request->get('user');

        $validated = $request->validate([
            'store_name' => ['required'],
            'description' => ['nullable']
        ]);

        if ($user->store) {

            return response()->json([
                'status' => false,
                'message' => 'User sudah memiliki toko'
            ], 400);
        }

        $store = Store::create([
            'user_id' => $user->id,
            'store_name' => $validated['store_name'],
            'description' => $validated['description']
        ]);

        $user->update([
            'role' => 'seller'
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Store berhasil dibuat',
            'data' => $store
        ]);
    }

        public function getMyStore(Request $request)
    {
        $user = $request->get('user');

        $store = Store::where('user_id', $user->id)->first();

        if (!$store) {

            return response()->json([
                'status' => false,
                'message' => 'Store tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $store
        ]);
    }

        public function getStores()
    {
        $stores = Store::latest()->get();

        return response()->json([
            'status' => true,
            'data' => $stores
        ]);
    }

    public function getStoreDetail($id)
    {
        $store = Store::find($id);

        if (!$store) {

            return response()->json([
                'status' => false,
                'message' => 'Store tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'status' => true,
            'data' => $store
        ]);
    }

        public function updateStore(Request $request)
    {
        $user = $request->get('user');

        $store = Store::where('user_id', $user->id)->first();

        if (!$store) {

            return response()->json([
                'status' => false,
                'message' => 'Store tidak ditemukan'
            ], 404);
        }

        $validated = $request->validate([
            'store_name' => ['required'],
            'description' => ['nullable']
        ]);

        $store->update([
            'store_name' => $validated['store_name'],
            'description' => $validated['description']
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Store berhasil diupdate',
            'data' => $store
        ]);
    }

    public function getStoreProducts($id)
    {
        $store = Store::find($id);

        if (!$store) {

            return response()->json([
                'status' => false,
                'message' => 'Store tidak ditemukan'
            ], 404);
        }

        $products = Product::where('store_id', $store->id)
            ->with(['category', 'images'])
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $products
        ]);
    }
}
