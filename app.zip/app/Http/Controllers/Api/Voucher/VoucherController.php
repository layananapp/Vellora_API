<?php

namespace App\Http\Controllers\Api\Voucher;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;    
use App\Models\Voucher;


class VoucherController extends Controller
{
    public function createVoucher(Request $request)
    {
        $validated = $request->validate([
            'code' => ['required', 'unique:vouchers,code'],
            'voucher_name' => ['required'],
            'discount_type' => ['required', 'in:percentage,fixed'],
            'discount_value' => ['required', 'numeric'],
            'minimum_transaction' => ['nullable', 'numeric'],
            'quota' => ['required', 'integer'],
            'expired_at' => ['nullable', 'date']
        ]);

        $voucher = Voucher::create([
            'code' => $validated['code'],
            'voucher_name' => $validated['voucher_name'],
            'discount_type' => $validated['discount_type'],
            'discount_value' => $validated['discount_value'],
            'minimum_transaction' => $validated['minimum_transaction'] ?? 0,
            'quota' => $validated['quota'],
            'expired_at' => $validated['expired_at'] ?? null,
            'is_active' => true
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Voucher berhasil dibuat',
            'data' => $voucher
        ]);
    }

    public function getVouchers()
    {
        $vouchers = Voucher::where('is_active', true)
            ->latest()
            ->get();

        return response()->json([
            'status' => true,
            'data' => $vouchers
        ]);
    }
}
