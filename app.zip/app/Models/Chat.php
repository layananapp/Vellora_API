<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\ChatRoom;
use App\Models\User;

class Chat extends Model
{
    protected $fillable = [
        'chat_room_id',
        'sender_id',
        'message'
    ];

    public function room()
    {
        return $this->belongsTo(ChatRoom::class, 'chat_room_id');
    }

    public function sender()
    {
        return $this->belongsTo(User::class, 'sender_id');
    }
}
