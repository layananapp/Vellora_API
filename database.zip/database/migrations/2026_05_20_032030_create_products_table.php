<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('products', function (Blueprint $table) {
        $table->id();

        $table->foreignId('store_id')
            ->constrained()
            ->onDelete('cascade');

        $table->foreignId('category_id')
            ->nullable()
            ->constrained()
            ->nullOnDelete();

        $table->string('product_name');

        $table->text('description')->nullable();

        $table->decimal('price', 12, 2);

        $table->integer('stock')->default(0);

        $table->boolean('is_active')->default(true);

        $table->softDeletes();
        $table->timestamps();
        
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
